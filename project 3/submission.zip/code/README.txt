CS180 Project 2: Fun with Filters and Frequencies
Sohum Phadke
Website: https://sophadke.github.io/cs180/project2/project2.html

HOW TO RUN
  Put the input images in an images/ folder next to code/ (list below), then:
      cd code
      python3 main.py
  Results are written to web/results/. Parts whose input images are missing
  are skipped with a message naming the files to add.

  Requirements: numpy, scipy, matplotlib, scikit-image, opencv-python

FILES
  main.py           Runs every part in order.
  convolution.py    Part 1.1: convolution from scratch with numpy only
                    (conv_four_loops and conv_two_loops, zero padding, flipped kernel).
  part1_filters.py  Part 1.1 timing vs scipy.signal.convolve2d; 1.2 finite differences,
                    gradient magnitude and edge thresholds; 1.3 Gaussian smoothing and
                    derivative-of-Gaussian filters; bells & whistles gradient orientation (HSV).
  part2_sharpen.py  Part 2.1: unsharp mask filter, alpha sweep, blur/re-sharpen evaluation.
  part2_hybrid.py   Part 2.2: hybrid images (Gaussian low-pass + impulse-minus-Gaussian
                    high-pass), alignment from clicked points, Fourier analysis, color variants.
  part2_blend.py    Parts 2.3 and 2.4: Gaussian/Laplacian stacks (no built-in pyramid
                    functions), Figure 3.42 recreation, multiresolution blending with
                    step and elliptical masks, grayscale vs color.
  pick_points.py    Click two matching points (the eyes) on each hybrid pair; saves
                    images/<pair>_points.json used for alignment.
  utils.py          Loading/saving images, Gaussian kernels, blur, FFT plots.

INPUT IMAGES (in images/)
  me.jpg                               1.1 photo of me
  cameraman.png                        1.2/1.3 (skimage's built-in copy is used if absent)
  taj.jpg, sharpen_mine.jpg            2.1 images to sharpen
  sharp_test.jpg                       2.1 sharp photo for the blur/re-sharpen test
  DerekPicture.jpg, nutmeg.jpg         2.2 sample hybrid
  pair2_far.jpg, pair2_close.jpg       2.2 me now / older
  pair3_far.jpg, pair3_close.jpg       2.2 my dog, grinning / curious
  apple.jpeg, orange.jpeg              2.3/2.4 oraple
  blend2_a.jpg, blend2_b.jpg           2.4 beach, morning / evening (horizontal seam)
  blend3_a.jpg, blend3_b.jpg           2.4 my face / painting (elliptical mask)

KEY PARAMETERS
  Edge thresholds: 0.25 (finite difference), 0.07 (after Gaussian, sigma = 1.5)
  Sharpening: sigma = 2, alpha = 1.5 (sweep 0.5, 1, 2, 4)
  Hybrids: sigma_low = 6, sigma_high = 3
  Stacks: 6 levels, sigma 2, 4, 8, 16, 32; mask stack starts at sigma = 8
